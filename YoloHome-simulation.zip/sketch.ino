#include <WiFi.h>
#include <PubSubClient.h>
#include <LiquidCrystal_I2C.h>
#include <ESP32Servo.h>
#include <Adafruit_NeoPixel.h>
#include "DHT.h"

// Config
const char* ssid = "Wokwi-GUEST";
const char* password = "";
const char* mqtt_server = "io.adafruit.com";
const char* mqtt_user = "NguyenHaoKhang"; 
const char* mqtt_pass = "aio_LJAD446WlMTEIaHnmUY89pu59yHF"; 

WiFiClient espClient;
PubSubClient client(espClient);

// Standard ESP32 Pins
#define PIN_RGB    27  
#define PIN_FAN    12  
#define PIN_SERVO  15  
#define PIN_PIR    13  
#define PIN_DHT    14  
#define PIN_LIGHT  34  // ADC1 pin, optimal for ESP32 with WiFi

// Devices
LiquidCrystal_I2C lcd(0x27, 16, 2); // Default SDA=21, SCL=22
Adafruit_NeoPixel rgbLamp(1, PIN_RGB, NEO_GRB + NEO_KHZ800);
Servo myServo;
DHT dht(PIN_DHT, DHT22);

// Global States
int auth_state = 10;
int last_pir_state = LOW;
int countdown_timer = 0;
int anim_frame = 0;

// Timers
unsigned long last_anim_time = 0;
unsigned long last_countdown_time = 0;
unsigned long last_env_time = 0;
unsigned long last_pir_time = 0;

// Topics
const char* topic_led   = "NguyenHaoKhang/feeds/yolohome.led";
const char* topic_fan   = "NguyenHaoKhang/feeds/yolohome.fan";
const char* topic_servo = "NguyenHaoKhang/feeds/yolohome.servo";
const char* topic_auth  = "NguyenHaoKhang/feeds/yolohome.auth";
const char* topic_temp  = "NguyenHaoKhang/feeds/yolohome.temp";
const char* topic_humi  = "NguyenHaoKhang/feeds/yolohome.humi";
const char* topic_light = "NguyenHaoKhang/feeds/yolohome.light";

void callback(char* topic, byte* payload, unsigned int length) {
  String msg = "";
  for (int i = 0; i < length; i++) msg += (char)payload[i];
  String currentTopic = String(topic);
  int val = msg.toInt();

  Serial.println("MQTT In: " + currentTopic + " -> " + msg);

  if (currentTopic == topic_led) {
    if (val == 0) rgbLamp.setPixelColor(0, rgbLamp.Color(0, 0, 0));
    else if (val == 1) rgbLamp.setPixelColor(0, rgbLamp.Color(255, 255, 255));
    else if (val == 2) rgbLamp.setPixelColor(0, rgbLamp.Color(0, 255, 0));
    else if (val == 3) rgbLamp.setPixelColor(0, rgbLamp.Color(255, 0, 0));
    rgbLamp.show();
  }
  else if (currentTopic == topic_fan) {
    if (val == 4) analogWrite(PIN_FAN, 0);
    else if (val == 5) analogWrite(PIN_FAN, 85); 
    else if (val == 6) analogWrite(PIN_FAN, 170); 
    else if (val == 7) analogWrite(PIN_FAN, 255); 
  }
  else if (currentTopic == topic_servo) {
    if (val == 8) myServo.write(0);
    else if (val == 9) myServo.write(90);
  }
  else if (currentTopic == topic_auth) {
    auth_state = val;

    if (auth_state == 10) {
      lcd.noBacklight();
      lcd.clear();
      countdown_timer = 0;
    } 
    else if (auth_state == 11) {
      lcd.backlight();
      lcd.clear();
      lcd.setCursor(4, 0); lcd.print("Welcome!");
      lcd.setCursor(0, 1); lcd.print("Look at camera");
      countdown_timer = 0;
    } 
    else if (auth_state == 12) {
      lcd.backlight();
      lcd.clear();
      lcd.setCursor(1, 0); lcd.print("Verifying face");
      rgbLamp.setPixelColor(0, rgbLamp.Color(255, 255, 255)); 
      rgbLamp.show();
      countdown_timer = 0;
      anim_frame = 0;
    } 
    else if (auth_state == 13) {
      lcd.backlight();
      lcd.clear();
      lcd.setCursor(2, 0); lcd.print("Auth success");
      rgbLamp.setPixelColor(0, rgbLamp.Color(0, 255, 0)); 
      rgbLamp.show();
      myServo.write(90);
      countdown_timer = 10;
    } 
    else if (auth_state == 14) {
      lcd.backlight();
      lcd.clear();
      lcd.setCursor(2, 0); lcd.print("Auth failed!");
      lcd.setCursor(3, 1); lcd.print("Try again.");
      rgbLamp.setPixelColor(0, rgbLamp.Color(255, 0, 0)); 
      rgbLamp.show();
      countdown_timer = 3;
    }
  }
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Connecting MQTT...");
    if (client.connect("ESP32_Wokwi_Khang", mqtt_user, mqtt_pass)) {
      Serial.println(" OK!");
      client.subscribe(topic_led);
      client.subscribe(topic_fan);
      client.subscribe(topic_servo);
      client.subscribe(topic_auth);
    } else {
      Serial.println(" Failed. Retrying...");
      delay(3000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  
  pinMode(PIN_FAN, OUTPUT);
  pinMode(PIN_PIR, INPUT);
  
  myServo.attach(PIN_SERVO); 
  myServo.write(0);
  
  rgbLamp.begin();
  rgbLamp.setPixelColor(0, rgbLamp.Color(0,0,0));
  rgbLamp.show();
  
  dht.begin();
  
  lcd.init(); 
  lcd.backlight();
  lcd.setCursor(3, 0); lcd.print("Yolo Home");
  
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) { delay(500); }
  
  client.setServer(mqtt_server, 1883);
  client.setCallback(callback);
}

void loop() {
  if (!client.connected()) reconnect();
  client.loop();

  unsigned long currentMillis = millis();

  // Anim: 4 dots loading
  if (auth_state == 12 && currentMillis - last_anim_time >= 300) {
    last_anim_time = currentMillis;
    String anim_str = "      ....      ";
    anim_str[6 + anim_frame] = 'o';
    lcd.setCursor(0, 1);
    lcd.print(anim_str);
    anim_frame = (anim_frame + 1) % 4;
  }

  // Auto Countdown
  if ((auth_state == 13 || auth_state == 14) && countdown_timer > 0 && currentMillis - last_countdown_time >= 1000) {
    last_countdown_time = currentMillis;
    
    if (auth_state == 13) {
      lcd.setCursor(1, 1);
      lcd.print("Closing in: " + String(countdown_timer) + "s ");
    }
    countdown_timer--;

    if (countdown_timer == 0) {
      if (auth_state == 13) myServo.write(0);
      rgbLamp.setPixelColor(0, rgbLamp.Color(0,0,0)); 
      rgbLamp.show();
      lcd.clear(); 
      lcd.noBacklight();
      
      auth_state = 10;
      client.publish(topic_auth, "10");
    }
  }

  // Read PIR (Only trigger 11 on Rising Edge if system is Idle)
  if (countdown_timer == 0 && currentMillis - last_pir_time >= 500) {
    last_pir_time = currentMillis;
    int current_pir = digitalRead(PIN_PIR);
    
    if (current_pir == HIGH && last_pir_state == LOW && auth_state == 10) {
      client.publish(topic_auth, "11");
      auth_state = 11; 
    }
    last_pir_state = current_pir;
  }

  // Publish Env Data
  if (currentMillis - last_env_time >= 30000) {
    last_env_time = currentMillis;
    float t = dht.readTemperature();
    float h = dht.readHumidity();
    int light_val = map(analogRead(PIN_LIGHT), 0, 4095, 0, 100);
    
    if (!isnan(t) && !isnan(h)) {
      client.publish(topic_temp, String(t).c_str());
      client.publish(topic_humi, String(h).c_str());
      client.publish(topic_light, String(light_val).c_str());
    }
  }
}